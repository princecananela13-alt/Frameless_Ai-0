package com.frameless.panel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Collections;
import java.util.Locale;
import java.util.Map;

/**
 * Draws the in-game panel as a system overlay.
 *  - a thin handle on the screen edge (always visible while the service runs)
 *  - swipe it inward (or tap it) -> the panel slides out
 *  - tap outside the panel -> it closes
 * The Frameless_AI module starts this service when a game from "My games" comes to the front
 * and stops it when you leave the game.
 */
public class PanelService extends Service {
    static final int BG = 0xF2120D1C;
    static final int CARD = 0xFF1E1730;
    static final int ACC = 0xFF8B5CF6;
    static final int ACC2 = 0xFFA78BFA;
    static final int TXT = 0xFFEDE9FE;
    static final int MUT = 0xFF9A8FB5;
    static final int OK = 0xFF34D399;

    private WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private float density = 1f;

    private View handle;
    private FrameLayout panelRoot;
    private View panelScroll;
    private boolean right = true;
    private boolean open = false;
    private String pkg = "";
    private String label = "Game";

    private TextView tvName, tvBat, tvTemp, tvRam, tvMode, tvMsg;
    private final TextView[] chips = new TextView[3];
    private final String[] profIds = {"gaming", "boost", "balanced"};
    private final String[] profNames = {"Arena", "Surge", "Everyday"};
    private TextView tileDnd, tileByp;
    private boolean dndOn = false, bypOn = false;

    // ------------------------------------------------------------------ lifecycle

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        density = getResources().getDisplayMetrics().density;
        getFilesDir(); // make sure the folder exists for the module's status/cmd files
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        startFg();
        if (i != null) {
            String p = i.getStringExtra("pkg");
            if (p != null) pkg = p;
            String s = i.getStringExtra("side");
            if (s != null) right = !"l".equals(s);
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        label = resolveLabel(pkg);
        closePanel(false);
        panelRoot = null; // rebuilt with the new game name / side
        buildHandle();
        return START_REDELIVER_INTENT;
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        closePanel(false);
        panelRoot = null;
        buildHandle();
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        open = false;
        removeView(panelRoot);
        removeView(handle);
        handle = null;
        super.onDestroy();
    }

    private void startFg() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel("panel", "Game panel", NotificationManager.IMPORTANCE_MIN);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, "panel")
                    : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_menu_manage)
                    .setContentTitle("Frameless Game Panel")
                    .setContentText("Swipe from the screen edge to open");
            startForeground(1, b.build());
        } catch (Exception ignored) {
        }
    }

    private String resolveLabel(String p) {
        if (p == null || p.isEmpty() || p.equals(getPackageName())) return "Preview";
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(p, 0)));
        } catch (Exception e) {
            return p;
        }
    }

    // ------------------------------------------------------------------ helpers

    private int dp(float v) {
        return Math.round(v * density);
    }

    private DisplayMetrics real() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return dm;
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void removeView(View v) {
        if (v == null) return;
        try {
            if (v.getParent() != null) wm.removeViewImmediate(v);
        } catch (Exception ignored) {
        }
    }

    private GradientDrawable round(int color, float radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) d.setStroke(Math.max(1, dp(1)), strokeColor);
        return d;
    }

    private TextView tv(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        t.setIncludeFontPadding(false);
        return t;
    }

    // ------------------------------------------------------------------ edge handle

    private void buildHandle() {
        removeView(handle);
        FrameLayout strip = new FrameLayout(this);
        View bar = new View(this);
        bar.setBackground(round(0x99FFFFFF, 3, 0));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(4), dp(64));
        bp.gravity = Gravity.CENTER_VERTICAL | (right ? Gravity.RIGHT : Gravity.LEFT);
        bp.leftMargin = dp(3);
        bp.rightMargin = dp(3);
        strip.addView(bar, bp);

        strip.setOnTouchListener(new EdgeTouch());
        if (Build.VERSION.SDK_INT >= 29) {
            strip.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                @Override
                public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int orr, int ob) {
                    v.setSystemGestureExclusionRects(Collections.singletonList(new Rect(0, 0, r - l, b - t)));
                }
            });
        }

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                dp(26), dp(170), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | (right ? Gravity.RIGHT : Gravity.LEFT);
        lp.y = Math.round(real().heightPixels * 0.28f);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        try {
            wm.addView(strip, lp);
            handle = strip;
        } catch (Exception e) {
            handle = null;
        }
    }

    private class EdgeTouch implements View.OnTouchListener {
        private float x0;
        private boolean fired;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    x0 = e.getRawX();
                    fired = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float d = e.getRawX() - x0;
                    if (!fired && (right ? d < -dp(16) : d > dp(16))) {
                        fired = true;
                        openPanel();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!fired && Math.abs(e.getRawX() - x0) < dp(6)) openPanel(); // a tap works too
                    return true;
                default:
                    return true;
            }
        }
    }

    // ------------------------------------------------------------------ panel

    private WindowManager.LayoutParams fullParams() {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return p;
    }

    private TextView stat(LinearLayout parent, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        TextView a = tv(title, 9, MUT, true);
        a.setLetterSpacing(0.1f);
        TextView b = tv("--", 14, TXT, true);
        b.setPadding(0, dp(3), 0, 0);
        c.addView(a);
        c.addView(b);
        parent.addView(c, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }

    private TextView tile(String text) {
        TextView t = tv(text, 12, TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(CARD, 10, 0x22A78BFA));
        return t;
    }

    private void setOn(TextView t, boolean on) {
        t.setBackground(round(on ? 0x558B5CF6 : CARD, 10, on ? ACC : 0x22A78BFA));
        t.setTextColor(on ? 0xFFFFFFFF : TXT);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private LinearLayout.LayoutParams cell(int heightDp, boolean gapRight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(heightDp), 1f);
        if (gapRight) p.rightMargin = dp(6);
        return p;
    }

    private TextView section(String s) {
        TextView t = tv(s, 9, MUT, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(dp(2), dp(10), 0, dp(5));
        return t;
    }

    private void buildPanel() {
        DisplayMetrics dm = real();
        int cardW = Math.min(dp(300), dm.widthPixels - dp(40));

        panelRoot = new FrameLayout(this);
        panelRoot.setBackgroundColor(0x66000000);
        panelRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closePanel(true);
            }
        });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(10));

        // header
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = tv("GAME PANEL", 9, ACC2, true);
        t1.setLetterSpacing(0.14f);
        tvName = tv(label, 16, TXT, true);
        tvName.setSingleLine(true);
        tvName.setEllipsize(TextUtils.TruncateAt.END);
        tvName.setPadding(0, dp(2), 0, 0);
        titles.addView(t1);
        titles.addView(tvName);
        head.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView x = tv("\u2715", 16, MUT, false);
        x.setPadding(dp(10), dp(4), dp(2), dp(4));
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closePanel(true);
            }
        });
        head.addView(x);
        card.addView(head);

        // stats
        LinearLayout stats = row();
        stats.setBackground(round(CARD, 12, 0));
        stats.setPadding(0, dp(8), 0, dp(8));
        tvBat = stat(stats, "BATTERY");
        tvTemp = stat(stats, "TEMP");
        tvRam = stat(stats, "RAM FREE");
        tvMode = stat(stats, "MODE");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(10);
        card.addView(stats, sp);

        // profile
        card.addView(section("PROFILE"));
        LinearLayout pr = row();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView c = tv(profNames[i], 12, TXT, true);
            c.setGravity(Gravity.CENTER);
            c.setBackground(round(CARD, 10, 0x22A78BFA));
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bus.send(PanelService.this, "prof " + profIds[idx]);
                    highlight(profIds[idx]);
                    tvMsg.setText("Switching profile\u2026");
                }
            });
            chips[i] = c;
            pr.addView(c, cell(34, i < 2));
        }
        card.addView(pr);

        // quick actions
        card.addView(section("QUICK ACTIONS"));
        tileDnd = tile("Do Not Disturb");
        TextView tRam = tile("Clean RAM");
        TextView tShot = tile("Screenshot");
        TextView tPing = tile("Ping");
        tileByp = tile("Pause charging");

        tileDnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dndOn = !dndOn;
                setOn(tileDnd, dndOn);
                Bus.send(PanelService.this, "dnd " + (dndOn ? 1 : 0));
            }
        });
        tRam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bus.send(PanelService.this, "kill");
                tvMsg.setText("Cleaning\u2026");
            }
        });
        tShot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closePanel(false); // so the panel is not in the picture
                Bus.send(PanelService.this, "shot");
            }
        });
        tPing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bus.send(PanelService.this, "ping");
                tvMsg.setText("Pinging\u2026");
            }
        });
        tileByp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bypOn = !bypOn;
                setOn(tileByp, bypOn);
                Bus.send(PanelService.this, "byp " + (bypOn ? 1 : 0));
            }
        });

        LinearLayout r1 = row();
        r1.addView(tileDnd, cell(38, true));
        r1.addView(tRam, cell(38, false));
        LinearLayout r2 = row();
        r2.addView(tShot, cell(38, true));
        r2.addView(tPing, cell(38, false));
        LinearLayout r3 = row();
        r3.addView(tileByp, cell(38, false));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gap.bottomMargin = dp(6);
        card.addView(r1, gap);
        LinearLayout.LayoutParams gap2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gap2.bottomMargin = dp(6);
        card.addView(r2, gap2);
        card.addView(r3);

        tvMsg = tv("Waiting for Frameless_AI\u2026", 11, MUT, false);
        tvMsg.setPadding(dp(2), dp(10), 0, 0);
        card.addView(tvMsg);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClickable(true); // taps on the card must not close the panel
        sv.setBackground(round(BG, 18, 0x44A78BFA));
        sv.addView(card, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.CENTER_VERTICAL | (right ? Gravity.RIGHT : Gravity.LEFT);
        lp.topMargin = dp(8);
        lp.bottomMargin = dp(8);
        lp.leftMargin = dp(8);
        lp.rightMargin = dp(8);
        panelRoot.addView(sv, lp);
        panelScroll = sv;
    }

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (!open) return;
            refresh();
            h.postDelayed(this, 1500);
        }
    };

    private void openPanel() {
        if (open) return;
        if (panelRoot == null) buildPanel();
        removeView(panelRoot); // in case a close animation is still running
        try {
            wm.addView(panelRoot, fullParams());
        } catch (Exception e) {
            return;
        }
        open = true;
        if (handle != null) handle.setVisibility(View.INVISIBLE);
        panelScroll.setTranslationX(right ? dp(320) : -dp(320));
        panelScroll.animate().translationX(0).setDuration(190).start();
        panelRoot.setAlpha(0f);
        panelRoot.animate().alpha(1f).setDuration(160).start();
        refresh();
        h.postDelayed(poll, 1200);
    }

    private void closePanel(boolean animate) {
        if (!open) return;
        open = false;
        h.removeCallbacks(poll);
        if (handle != null) handle.setVisibility(View.VISIBLE);
        final View root = panelRoot;
        if (root == null) return;
        if (animate && panelScroll != null) {
            panelScroll.animate().translationX(right ? dp(320) : -dp(320)).setDuration(150).start();
            root.animate().alpha(0f).setDuration(150).withEndAction(new Runnable() {
                @Override
                public void run() {
                    if (!open) removeView(root);
                }
            }).start();
        } else {
            root.animate().cancel();
            removeView(root);
        }
    }

    // ------------------------------------------------------------------ live data

    private void highlight(String prof) {
        for (int i = 0; i < 3; i++) {
            boolean on = profIds[i].equals(prof);
            chips[i].setBackground(round(on ? 0x558B5CF6 : CARD, 10, on ? ACC : 0x22A78BFA));
            chips[i].setTextColor(on ? 0xFFFFFFFF : TXT);
        }
    }

    private long num(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private void refresh() {
        if (tvBat == null) return;
        Map<String, String> m = Bus.read(this);
        long ts = num(m.get("ts") == null ? "0" : m.get("ts"));
        long now = System.currentTimeMillis() / 1000;
        if (ts == 0 || Math.abs(now - ts) > 8) {
            tvBat.setText("--");
            tvTemp.setText("--");
            tvRam.setText("--");
            tvMode.setText("--");
            tvMsg.setText("Waiting for Frameless_AI\u2026");
            return;
        }
        tvBat.setText(m.get("bat") + "%");
        tvTemp.setText(m.get("temp") + "\u00B0");
        long ram = num(m.get("ram") == null ? "0" : m.get("ram"));
        tvRam.setText(ram >= 1024 ? String.format(Locale.US, "%.1fG", ram / 1024f) : ram + "M");
        String prof = m.get("prof") == null ? "" : m.get("prof");
        String mode = prof;
        for (int i = 0; i < 3; i++) if (profIds[i].equals(prof)) mode = profNames[i];
        tvMode.setText(mode.isEmpty() ? "--" : mode);
        highlight(prof);
        dndOn = "1".equals(m.get("dnd"));
        bypOn = "1".equals(m.get("byp"));
        setOn(tileDnd, dndOn);
        setOn(tileByp, bypOn);
        String msg = m.get("msg");
        tvMsg.setText(msg == null || msg.isEmpty() ? "Ready" : msg);
    }
}
