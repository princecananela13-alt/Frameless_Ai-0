package com.frameless.panel;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * Tiny file channel between this (unprivileged) app and the Frameless_AI root daemon.
 *   files/status : written by the module every ~2 s   (key=value lines)
 *   files/cmd    : written by this app, read + cleared by the module (one command per line)
 * The module only accepts a fixed list of commands, so the app can never run anything else.
 */
final class Bus {
    private Bus() {}

    static void send(Context c, String cmd) {
        try (FileOutputStream o = new FileOutputStream(new File(c.getFilesDir(), "cmd"), true)) {
            o.write((cmd + "\n").getBytes("UTF-8"));
        } catch (Exception ignored) {
        }
    }

    static Map<String, String> read(Context c) {
        Map<String, String> m = new HashMap<>();
        File f = new File(c.getFilesDir(), "status");
        if (!f.exists()) return m;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            String l;
            while ((l = br.readLine()) != null) {
                int i = l.indexOf('=');
                if (i > 0) m.put(l.substring(0, i), l.substring(i + 1));
            }
        } catch (Exception ignored) {
        }
        return m;
    }
}
